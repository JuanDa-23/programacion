import java.util.Scanner;

public class Ejercicio21 {
    public static void main(String[] args) {
        int suma = 0;
        for (int i = 2; i <= 1000; i += 2) {
            suma += i;
        }
        System.out.println("El resultado de la suma de los pares es: " + suma);

            }
        }
